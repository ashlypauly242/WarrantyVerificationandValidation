const contract = artifacts.require("WarrantyVerification")

module.exports = (deployer) => {
  deployer.deploy(contract);
}
