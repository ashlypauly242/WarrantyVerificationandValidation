import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {AdminRoutingModule} from './admin-routing.module';
import {DashboardComponent} from './dashboard/dashboard.component';
import {HomeComponent} from './home/home.component';
import {ButtonModule} from "primeng/button";
import {DialogModule} from "primeng/dialog";
import {RippleModule} from "primeng/ripple";
import {TableModule} from "primeng/table";
import {FormsModule} from "@angular/forms";
import {InputTextModule} from "primeng/inputtext";
import {SharedModule} from "../shared/shared.module";
import {CompanyComponent} from './company/company.component';


@NgModule({
  declarations: [
    DashboardComponent,
    HomeComponent,
    CompanyComponent,
  ],
  imports: [
    CommonModule,
    AdminRoutingModule,
    ButtonModule,
    DialogModule,
    RippleModule,
    TableModule,
    FormsModule, InputTextModule, SharedModule
  ]
})
export class AdminModule {
}
