import {Component, OnInit, ViewChild} from '@angular/core';
import {CompanyType} from "../../types/company.type";
import {AdminService} from "../services/admin.service";
import {ProgressCardComponent} from "../../shared/progress-card/progress-card.component";

@Component({
  selector: 'app-company',
  templateUrl: './company.component.html',
  styleUrl: './company.component.sass'
})
export class CompanyComponent implements OnInit {
  @ViewChild(ProgressCardComponent) prgCard!: ProgressCardComponent
  companies: CompanyType[] = [];
  addModalVisible: boolean = false;
  company: CompanyType = {
    name: '',
    id: ''
  }

  constructor(private as: AdminService) {
  }

  ngOnInit() {
    this.getAllCompanies()
  }

  getAllCompanies() {
    this.as.getAllCompanies().then((r: CompanyType[]) => {
      console.log(r)
      this.companies = r
    })
  }

  addNewCompany() {
    this.addModalVisible = false
    this.prgCard.setProgress('Adding new company', 0)
    if(this.company.name.length < 1){
      this.prgCard.setProgress('Company name is mandatory', 3)
      return
    }
    if(this.company.id.length < 42){
      this.prgCard.setProgress('Company id is mandatory', 3)
      return
    }

    this.as.addCompany(this.company).then(r => {
      this.prgCard.setProgress('Successfully added company', 1)
      this.getAllCompanies()
    }).catch(err => {
      this.prgCard.setProgress('Failed adding new company', 3)
      console.log(err)
    })
  }

  showAddModal() {
    this.addModalVisible = !this.addModalVisible
  }

}
