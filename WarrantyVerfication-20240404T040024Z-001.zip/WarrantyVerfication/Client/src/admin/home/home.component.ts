import {Component, OnInit} from '@angular/core';
import {AdminService} from "../services/admin.service";

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrl: './home.component.sass'
})
export class HomeComponent implements OnInit {

  counts!:{ 0: string, 1: string, 2: string, 3: string }

  constructor(private as: AdminService) {
  }

  ngOnInit() {
    this.getCounts()
  }

  getCounts() {
    this.as.getCount().then((r: { 0: string, 1: string, 2: string, 3: string }) => {
      console.log(r)
      this.counts = r
    })
  }
}
