import {Injectable, signal, WritableSignal} from '@angular/core';
import {Web3Service} from "../../services/web3.service";
import {CompanyType} from "../../types/company.type";

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  account: WritableSignal<string> = signal('')

  constructor(private ws: Web3Service) {
    this.account = ws.account
  }

  addCompany(company: CompanyType) {
    return new Promise((resolve, reject) => {
      this.ws.getContract().then(c => {
        // addCompany(address id, string memory name)
        c.methods['addCompany'](company.id, company.name)
          .send({from: this.account()})
          .on('confirmation', (r: any) => {
            resolve(r)
          }).on('error', (err: any) => {
          console.log(err)
        })
      })
    })
  }

  getAllCompanies(): Promise<CompanyType[]> {
    return new Promise((resolve, reject) => {
      //   getAllCompanies()
      this.ws.getContract().then(c => {
          c.methods['getAllCompanies']().call().then((r: CompanyType[]) => {
            resolve(r)
          }).catch((err: any) => {
            console.log(err)
            reject(err)
          })
        }
      )
    })
  }


  getCount(): Promise<any> {
    return new Promise((resolve, reject) => {
      this.ws.getContract().then(c => {
        c.methods['getCounts']().call().then((r: any) => {
          resolve(r)
        }).catch((err: any) => {
          reject(err)
        })
      })
    })
  }
}
