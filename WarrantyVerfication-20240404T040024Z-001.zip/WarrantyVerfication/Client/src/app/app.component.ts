import {Component, effect} from '@angular/core';
import {Web3Service} from "../services/web3.service";

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrl: './app.component.sass'
})
export class AppComponent {
  title = 'client';
  account: string = ''

  constructor(ws: Web3Service) {
    effect(() => {
      this.account = ws.account()
    });
  }
}
