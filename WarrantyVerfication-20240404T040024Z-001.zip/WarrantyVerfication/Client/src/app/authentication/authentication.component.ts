import {ChangeDetectorRef, Component, effect, OnInit, ViewChild} from '@angular/core';
import {UserType} from "../../types/user.type";
import {AuthService} from "../../services/auth.service";
import {Router} from "@angular/router";
import {ProgressCardComponent} from "../../shared/progress-card/progress-card.component";

@Component({
  selector: 'app-authentication',
  templateUrl: './authentication.component.html',
  styleUrls: ['./authentication.component.sass']
})
export class AuthenticationComponent implements OnInit {
  @ViewChild(ProgressCardComponent) prgCard!: ProgressCardComponent
  @ViewChild('regForm') regForm!: HTMLFormElement
  @ViewChild('loginForm') loginForm!: HTMLFormElement

  user: UserType = {
    email: "",
    id: "",
    name: "",
    password: "",
    phone: "",
  }

  userType: {
    admin: boolean;
    company: boolean;
    user: boolean;
  } = {
    admin: true,
    company: false, user: false
  }

  isRegister: boolean = false;
  isLogin: boolean = true;
  password: string = ''
  rPassword: string = '';

  userTypeId: number = 0

  userId: string = ''

  constructor(private as: AuthService, private router: Router, private cd: ChangeDetectorRef) {
    effect(() => {
      this.user.id = as.account()
    });
  }

  ngOnInit(): void {
  }


  register() {
    this.isRegister = true
    this.isLogin = false

    this.onUserToggle(3)
  }

  login() {
    this.isLogin = true
    this.isRegister = false
  }

  onUserToggle(userTypeId: number) {
    this.errorMsg = ''
    this.successMsg = ''
    this.userTypeId = userTypeId - 1;
    switch (userTypeId) {
      case 1:
        this.userType.admin = true
        this.userType.company = false
        this.userType.user = false
        break;
      case 2:
        this.userType.admin = false
        this.userType.company = true
        this.userType.user = false
        break;
      case 3:
        this.userType.admin = false
        this.userType.company = false
        this.userType.user = true
        break;
    }
  }

  //  isAdmin 100
//  incorrect admin password 101
//  user 200
//  incorrect user password 201
//  user not active 202
  errorMsg: string = '';
  successMsg: string = '';

  handleLogin() {
    this.prgCard.setProgress('Authenticating...', 1)
    console.log(this.user)
    this.errorMsg = ''
    this.user.password = this.password

    switch (this.userTypeId) {
      case 0:
        this.as.adminLogin(this.user).then(r => {
          if (1 === parseInt(String(r))) {
            this.as.isAdmin.set(true)
            this.router.navigate(['admin/']).then(r => {
            })
          } else {
            this.errorMsg = 'Incorrect Password'
            this.prgCard.setProgress('Incorrect Password', 3)
          }
        }).catch(err => {
          this.prgCard.setProgress('Not connected as Admin Account', 3)
          this.errorMsg = 'Not connected as Admin Account'
        })
        break;
      case 1:
        this.as.companyLogin(this.user).then(r => {
          if (1 === parseInt(String(r))) {
            this.as.isCompany.set(true)
            this.router.navigate(['company/']).then(r => {
            })
          } else {
            this.errorMsg = 'Incorrect Password'
            this.prgCard.setProgress('Incorrect Password', 3)
          }
        }).catch(err => {
          this.prgCard.setProgress('Not a registered Company', 3)
          this.errorMsg = 'Not a registered Company'
        })
        break;
      case 2:
        this.as.userLogin(this.user).then(r => {
          if (1 === parseInt(String(r))) {
            this.as.isUser.set(true)
            this.router.navigate(['user/']).then(r => {
            })
          } else {
            this.errorMsg = 'Incorrect Password'
            this.prgCard.setProgress('Incorrect Password', 3)
          }
        }).catch(err => {
          this.prgCard.setProgress('Not a registered User', 3)
          this.errorMsg = 'User Not Registered'
        })
        break;
    }

    // this.as.login({id: this.user.id, password: this.user.password || ''}).then(r => {
    //   console.log(this.userTypeId === undefined && Number(r) != 100 || Number(r) != 101)
    //   // if (this.userTypeId === undefined && Number(r) in [100,101]) {
    //   //   this.errorMsg = 'Not connected as admin'
    //   //   return
    //   // }
    //   //
    //   // console.log(this.userTypeId,this.userTypeId in [1,2,3] , (Number(r) in [100,101]))
    //   // if (this.userTypeId !== 0 && Number(r) in [100,101]) {
    //   //   this.errorMsg = `Not connected as ${this.userTypeId === 1 ? 'RMO' : this.userTypeId === 2 ? 'Doctor' : 'Patient'}`
    //   //   return;
    //   // }
    //
    //   if (Number(r) === 500) {
    //     this.prgCard.setProgress('Non Registered User', 3)
    //     return
    //   }
    //
    //   if (this.userTypeId === 0) {
    //     if (Number(r) === 100) {
    //       this.router.navigate(['admin/']).then(r => {
    //       })
    //     } else if (Number(r) === 101) {
    //       this.prgCard.setProgress('Incorrect Password', 3)
    //     } else {
    //       this.prgCard.setProgress('Invalid id', 3)
    //     }
    //     return;
    //   } else if (this.userTypeId === 1) {
    //     if (Number(r) === 200) {
    //       this.router.navigate(['rmo/']).then(r => {
    //       })
    //     } else if (Number(r) === 201) {
    //       this.prgCard.setProgress('Incorrect Password', 3)
    //
    //     } else if (Number(r) === 202) {
    //       this.prgCard.setProgress('Non Verified User', 3)
    //
    //     } else {
    //       this.prgCard.setProgress('Invalid id', 3)
    //     }
    //     return;
    //   } else if (this.userTypeId === 2) {
    //     if (Number(r) === 300) {
    //       this.router.navigate(['doctor/']).then(r => {
    //       })
    //     } else if (Number(r) === 201) {
    //       this.prgCard.setProgress('Incorrect Password', 3)
    //
    //     } else if (Number(r) === 202) {
    //       this.prgCard.setProgress('Non Verified User', 3)
    //
    //     } else {
    //       this.prgCard.setProgress('Invalid id', 3)
    //     }
    //     return;
    //   } else if (this.userTypeId === 3) {
    //     if (Number(r) === 400) {
    //       this.router.navigate(['patient/']).then(r => {
    //       })
    //     } else if (Number(r) === 201) {
    //       this.prgCard.setProgress('Incorrect Password', 3)
    //     } else if (Number(r) === 202) {
    //       this.prgCard.setProgress('Non Verified User', 3)
    //
    //     } else {
    //       this.prgCard.setProgress('Invalid id', 3)
    //     }
    //     return;
    //   } else if (Number(r) === 201) {
    //     this.prgCard.setProgress('Incorrect Password', 3)
    //
    //   } else if (Number(r) === 202) {
    //     this.prgCard.setProgress('Non Verified User', 3)
    //   }
    //
    // })
    this.clearForm()
  }

  handleRegister() {
    this.prgCard.setProgress('Registering new User', 0)
    this.user.password = this.password
    console.log(this.userTypeId)
    this.errorMsg = ""
    console.log(this.user, this.rPassword, this.userTypeId)
    this.as.registerUser(this.user).then(r => {
      this.successMsg = 'Registration successful'
      this.prgCard.setProgress('Registration successful', 1)
      this.clearForm()
    }).catch(err => {
      this.errorMsg = 'Registration failed'
      this.prgCard.setProgress('Registration failed', 3)
    })
  }

  clearForm() {
    // this.regForm.reset()
    // this.loginForm.reset()
    // this.setAccount()
  }
}
