import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';

import {CompanyRoutingModule} from './company-routing.module';
import {DashboardComponent} from './dashboard/dashboard.component';
import {WarrantyComponent} from './warranty/warranty.component';
import {SharedModule} from "../shared/shared.module";
import {ProductsComponent} from './products/products.component';
import {ButtonModule} from "primeng/button";
import {DialogModule} from "primeng/dialog";
import {FormsModule} from "@angular/forms";
import {InputTextModule} from "primeng/inputtext";
import {RippleModule} from "primeng/ripple";
import {TableModule} from "primeng/table";


@NgModule({
  declarations: [
    DashboardComponent,
    WarrantyComponent,
    ProductsComponent
  ],
  imports: [
    CommonModule,
    CompanyRoutingModule,
    SharedModule,
    ButtonModule,
    DialogModule,
    FormsModule,
    InputTextModule,
    RippleModule,
    SharedModule,
    TableModule
  ]
})
export class CompanyModule {
}
