import {Component, effect, OnInit} from '@angular/core';
import {NavigationEnd, Router} from "@angular/router";
import {AuthService} from "../../services/auth.service";

@Component({
  selector: 'app-dashboard',
  templateUrl: './dashboard.component.html',
  styleUrl: './dashboard.component.sass'
})
export class DashboardComponent implements OnInit {

  navs = [
    {title: 'Products', icon: 'fa solid fa-cubes-stacked', route: '/company/products', active: false},
    {title: 'Warranties', icon: 'fa-solid fa-newspaper', route: '/company/warranty', active: false},
  ]
  isCompany: boolean = false;

  constructor(private router: Router, as: AuthService) {
    effect(() => {
      this.isCompany = as.isCompany()
    });
  }

  ngOnInit() {
    this.router.navigate(['company/products']).then(r => {
      this.handleRouteChange('/company/products')
    })
    this.router.events.subscribe((ev) => {
      if (ev instanceof NavigationEnd) {
        this.handleRouteChange(ev.url)
      }
    })
  }

  handleRouteChange(route: string) {
    this.navs.map((n, i) => {
      n.route === route ? n.active = true : n.active = false
    })
  }

  handleLogOut() {
    this.router.navigate([''])
  }
}
