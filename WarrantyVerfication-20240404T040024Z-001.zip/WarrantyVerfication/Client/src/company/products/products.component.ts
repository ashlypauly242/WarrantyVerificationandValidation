import {Component, OnInit, ViewChild} from '@angular/core';
import {ProductType} from "../../types/product.type";
import {CompanyService} from "../services/company.service";
import {ProgressCardComponent} from "../../shared/progress-card/progress-card.component";

@Component({
  selector: 'app-products',
  templateUrl: './products.component.html',
  styleUrl: './products.component.sass'
})
export class ProductsComponent implements OnInit {
  @ViewChild(ProgressCardComponent) prgCard!: ProgressCardComponent
  products: ProductType[] = [];
  addModalVisible: boolean = false;
  product: ProductType = {companyId: "", id: 0, name: "", warrantyInYears: 0};

  constructor(private cs: CompanyService) {

  }

  ngOnInit() {
    this.getAllProducts()
  }

  showAddModal() {
    this.addModalVisible = true
  }

  addNewProduct() {
    this.addModalVisible = false
    this.prgCard.setProgress('Adding new product', 0)
    if (this.product.warrantyInYears < 1) {
      this.prgCard.setProgress('Product Warranty is mandatory', 3)
      return
    }
    if (this.product.name.length < 1) {
      this.prgCard.setProgress('Product name is mandatory', 3)
      return;
    }
    this.cs.addNewProduct(this.product).then(r => {
      this.prgCard.setProgress('Successfully added product', 1)
      this.getAllProducts()
    }).catch((err: any) => {
      this.prgCard.setProgress('Failed adding new product', 3)
      console.log(err)
    })
  }

  private getAllProducts() {
    this.cs.getAllProducts().then((r: ProductType[]) => {
      this.products = r
    }).catch(err => {
      console.log(err)
    })
  }
}
