import {Injectable, signal, WritableSignal} from '@angular/core';
import {Web3Service} from "../../services/web3.service";
import {ProductType} from "../../types/product.type";
import {WarrantyType} from "../../types/warranty.type";

@Injectable({
  providedIn: 'root'
})
export class CompanyService {

  account: WritableSignal<string> = signal('')

  constructor(private ws: Web3Service) {
    this.account = ws.account
  }

  addNewProduct(product: ProductType) {
    return new Promise((resolve, reject) => {

      this.ws.getContract().then(c => {
        // addProduct(string memory name, uint winy)
        c.methods['addProduct'](product.name, product.warrantyInYears)
          .send({from: this.account()})
          .on('confirmation', (r: any) => {
            resolve(r)
          })
          .on('error', (err: any) => {
            console.log(err)
            reject(err)
          })
      })
    })
  }

  getAllProducts(): Promise<ProductType[]> {
    return new Promise((resolve, reject) => {
        this.ws.getContract().then(c => {
          //   getCompanyProducts(address cId)
          c.methods['getCompanyProducts'](this.account())
            .call()
            .then((r: ProductType[]) => {
              resolve(r)
            })
            .catch((err: any) => {
              console.log(err)
            })
        })
      }
    )
  }

  getCompanyWarranties(): Promise<WarrantyType[]> {
    return new Promise((resolve, reject) => {
      this.ws.getContract().then(c => {
        c.methods['getCompanyWarranties'](this.account()).call()
          .then((r: string[]) => {
            let warranties: WarrantyType[] = []
            r.forEach((a, i) => {
              this.ws.mapWarrantyData(a).then(w => {
                warranties.push(w)
                if (warranties.length === r.length) resolve(warranties)
              })
            })
          })
          .catch((err: any) => {
            console.log(err)
            reject(err)
          })
      })
    })
  }

  approveWarranty(cId: string) {
    return new Promise((resolve, reject) => {
      this.ws.getWarrantyContract(cId).then(wc => {
        wc.methods['approveWarranty']()
          .send({from: this.account()})
          .on('confirmation', (r: any) => {
            resolve(true)
          }).catch((err: any) => {
          reject(err)
        })
      })
    })
  }

  rejectWarranty(cId: string) {
    return new Promise((resolve, reject) => {
      this.ws.getWarrantyContract(cId).then(wc => {
        wc.methods['rejectWarranty']()
          .send({from: this.account()})
          .on('confirmation', (r: any) => {
            resolve(true)
          }).catch((err: any) => {
          reject(err)
        })
      })
    })
  }

}
