import {Component, OnInit, ViewChild} from '@angular/core';
import {WarrantyType} from "../../types/warranty.type";
import {CompanyService} from "../services/company.service";
import {ProgressCardComponent} from "../../shared/progress-card/progress-card.component";

@Component({
  selector: 'app-warranty',
  templateUrl: './warranty.component.html',
  styleUrl: './warranty.component.sass'
})
export class WarrantyComponent implements OnInit {
  @ViewChild(ProgressCardComponent) prgCard!: ProgressCardComponent
  protected readonly parseInt = parseInt;
  warranties: WarrantyType[] = [];

  constructor(private cs: CompanyService) {
  }

  ngOnInit() {
    this.getAllWarranties()
  }

  getAllWarranties() {
    this.cs.getCompanyWarranties().then(r => {
      this.warranties = r
    })
  }

  onApproveWarranty(cid: string) {
    this.prgCard.setProgress('Approving warranty..', 0)
    this.cs.approveWarranty(cid).then(r => {
      this.prgCard.setProgress('Warranty approved', 1)
      this.getAllWarranties()
    }).catch(err => {
      this.prgCard.setProgress('Warranty approving failed', 3)
    })
  }

  onRejectWarranty(cid: string) {
    this.prgCard.setProgress('Rejecting warranty..', 0)
    this.cs.rejectWarranty(cid).then(r => {
      this.prgCard.setProgress('Warranty rejected', 1)
      this.getAllWarranties()
    }).catch(err => {
      this.prgCard.setProgress('Warranty rejecting failed', 3)
    })
  }
}
