import {Injectable, signal, WritableSignal} from '@angular/core';
import {Web3Service} from "./web3.service";
import {UserType} from "../types/user.type";

@Injectable({
  providedIn: 'root'
})
export class AuthService {

  account: WritableSignal<string> = signal('')

  public isAdmin: WritableSignal<boolean> = signal(false)
  public isCompany: WritableSignal<boolean> = signal(false)
  public isUser: WritableSignal<boolean> = signal(false)

  constructor(private ws: Web3Service) {
    this.account = ws.account
  }

  registerUser(user: UserType) {
    return new Promise((resolve, reject) => {
      this.ws.getContract().then(c => {
        // addUser(string memory password, string memory name, string memory email)
        c.methods['addUser'](user.password, user.name, user.email)
          .send({from: this.account()})
          .on('confirmation', (r: any) => {
            resolve(r)
          })
          .on('error', (err: any) => {
            console.log(err)
            reject(err)
          })
      })
    })
  }

  userLogin(user: UserType) {
    return new Promise((resolve, reject) => {
      this.ws.getContract().then(c => {
        c.methods['userLogin'](user.password)
          .call({from: this.account()})
          .then((r: any) => {
            resolve(r)
          })
          .catch((err: any) => {
            console.log(err)
            reject(err)
          })
      })
    })
  }

  adminLogin(user: UserType) {
    return new Promise((resolve, reject) => {
      this.ws.getContract().then(c => {
        c.methods['adminLogin'](user.password)
          .call({from: this.account()})
          .then((r: any) => {
            resolve(r)
          })
          .catch((err: any) => {
            console.log(err)
            reject(err)
          })
      })
    })
  }

  companyLogin(user: UserType) {
    return new Promise((resolve, reject) => {
      this.ws.getContract().then(c => {
        c.methods['companyLogin'](user.password)
          .call({from: this.account()})
          .then((r: any) => {
            resolve(r)
          })
          .catch((err: any) => {
            console.log(err)
            reject(err)
          })
      })
    })
  }
}
