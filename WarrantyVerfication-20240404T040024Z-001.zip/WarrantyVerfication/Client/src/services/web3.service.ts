import {Injectable, signal, WritableSignal} from '@angular/core';
import Web3 from "web3";
import VerificationContract from '../../build/contracts/WarrantyVerification.json'
import WarrantyContract from '../../build/contracts/Warranty.json'
import {WarrantyType} from "../types/warranty.type";
import {ProductType} from "../types/product.type";

@Injectable({
  providedIn: 'root'
})
export class Web3Service {

  web3!: Web3
  account: WritableSignal<string> = signal('');
  contract!: any


  constructor() {
    this.getWeb3Provider().then(w3 => {
      this.getContract().then(c => {
        console.log(c)
      })

      window?.ethereum?.on('accountsChanged', (acc: any) => {
        console.log(acc);
        this.account.set((acc as string[])?.[0])
        console.log(this.account)
        window.location.reload();
      });
    })
  }

  getContract(): Promise<any> {
    return new Promise((resolve, reject) => {
      if (this.contract) {
        resolve(this.contract)
      } else {
        const nwData = VerificationContract.networks[5777]
        if (nwData) {
          this.contract = new this.web3.eth.Contract(VerificationContract.abi as any, nwData.address)
          resolve(this.contract)
        }
      }
    })
  }

  getWarrantyContract(ad: string): Promise<any> {
    return new Promise((resolve, reject) => {
      resolve(new this.web3.eth.Contract(WarrantyContract.abi as any, ad))
    })
  }

  mapWarrantyData(w: string): Promise<WarrantyType> {
    return new Promise((resolve, reject) => {
      this.getWarrantyContract(w).then(wc => {
        wc.methods['getWarrantyData']().call().then((w: WarrantyType) => {

          this.contract.methods['getProduct'](w.productId).call().then((p: ProductType) => {
            console.log(p)
            // w.product = p as ProductType;
            resolve({...w, product: p});
          })
        })
      })
    })
  }

  async getWeb3Provider() {
    if (window.ethereum) {
      this.web3 = new Web3(window.ethereum);
      const accounts = await window.ethereum.request({
        method: 'eth_requestAccounts',
      });
      console.log(accounts)
      this.account.set((accounts as string[])?.[0])
      return this.web3;
    } else if (window.web3) {
      window.web3 = new Web3(window.web3.currentProvider);
      return window.web3;
    } else {
      return window.web3;
    }
  }

  get currentAccount() {
    return this.account();
  }

}
