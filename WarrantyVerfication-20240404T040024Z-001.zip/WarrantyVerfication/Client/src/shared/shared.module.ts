import {NgModule} from '@angular/core';
import {CommonModule} from '@angular/common';
import {ProgressCardComponent} from "./progress-card/progress-card.component";
import {ProgressSpinnerModule} from "primeng/progressspinner";
import {SidebarComponent} from "./sidebar/sidebar.component";
import {RouterModule} from "@angular/router";


@NgModule({
  declarations: [ProgressCardComponent, SidebarComponent],
  imports: [
    CommonModule,
    ProgressSpinnerModule, RouterModule
  ], exports: [ProgressCardComponent, SidebarComponent]
})
export class SharedModule {
}
