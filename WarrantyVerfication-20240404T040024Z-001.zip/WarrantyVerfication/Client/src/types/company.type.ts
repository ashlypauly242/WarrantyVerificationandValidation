export interface CompanyType {
  name: string
  id: string
  password?: string
}
