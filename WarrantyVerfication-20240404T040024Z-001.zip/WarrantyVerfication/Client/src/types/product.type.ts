export interface ProductType {
  id: number;
  name: string;
  warrantyInYears: number;
  companyId: string;
}
