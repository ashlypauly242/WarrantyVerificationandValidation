export interface UserType {
  email: string,
  id: string,
  name: string,
  password: string,
  phone: string,
}
