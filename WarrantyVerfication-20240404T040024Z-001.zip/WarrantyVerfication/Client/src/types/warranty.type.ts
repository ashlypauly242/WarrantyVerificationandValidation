import {ProductType} from "./product.type";

export interface WarrantyType {
  id: string;
  userId: string;
  companyId: string;
  productId: number;
  expiryDate: number;
  startDate: number;
  status?: number;
  createdOn?: number;
  product?: ProductType
  companyName?: string
}
