import {Injectable, signal, WritableSignal} from '@angular/core';
import {Web3Service} from "../../services/web3.service";
import {CompanyType} from "../../types/company.type";
import {ProductType} from "../../types/product.type";
import {WarrantyType} from "../../types/warranty.type";

@Injectable({
  providedIn: 'root'
})
export class UserService {

  account: WritableSignal<string> = signal('')

  constructor(private ws: Web3Service) {
    this.account = ws.account
  }

  getAllCompanies(): Promise<CompanyType[]> {
    return new Promise((resolve, reject) => {
      this.ws.getContract().then(c => {
        c.methods['getAllCompanies']().call().then((r: CompanyType[]) => {
          resolve(r)
        }).catch((err: any) => {
          console.log(err)
          reject(err)
        })
      })
    })
  }

  getCompanyProducts(cId: string): Promise<ProductType[]> {
    return new Promise((resolve, reject) => {
      this.ws.getContract().then(c => {
        c.methods['getCompanyProducts'](cId).call().then((r: ProductType[]) => {
          console.log(r)
          resolve(r)
        }).catch((err: any) => {
          console.log(err)
          reject(err)
        })
      })
    })
  }

  addWarranty(warranty: WarrantyType) {
    return new Promise((resolve, reject) => {
      this.ws.getContract().then(c => {
        // addWarranty(address cId, uint pId, uint eDate, uint sDate)
        c.methods['addWarranty'](warranty.companyId, warranty.productId, warranty.expiryDate, warranty.startDate)
          .send({from: this.account()})
          .on('confirmation', (r: any) => {
            resolve(r)
          })
          .on('error', (err: any) => {
            reject(err)
          })
      })
    })
  }

  getUserWarranties(): Promise<WarrantyType[]> {
    return new Promise((resolve, reject) => {
      this.ws.getContract().then(c => {
        // getUserWarranties(address uId)
        c.methods['getUserWarranties'](this.account()).call()
          .then((r: string[]) => {
            let warranties: WarrantyType[] = []
            r.forEach((a, i) => {
              this.ws.mapWarrantyData(a).then(w => {
                warranties.push(w)
                if (warranties.length === r.length) resolve(warranties)
              })
            })
          })
          .catch((err: any) => {
            console.log(err)
            reject(err)
          })
      })
    })
  }

  deleteWarranty(warranty: WarrantyType) {
    return new Promise((resolve, reject) => {
      this.ws.getContract().then(c => {
        // addWarranty(address cId, uint pId, uint eDate, uint sDate)
        c.methods['deleteWarranty'](warranty.id, warranty.companyId)
          .send({from: this.account()})
          .on('confirmation', (r: any) => {
            resolve(r)
          })
          .on('error', (err: any) => {
            reject(err)
          })
      })
    })
  }
}
