import {NgModule} from '@angular/core';
import {CommonModule, DatePipe} from '@angular/common';

import {UserRoutingModule} from './user-routing.module';
import {DashboardComponent} from './dashboard/dashboard.component';
import {SharedModule} from "../shared/shared.module";
import {WarrantiesComponent} from './warranties/warranties.component';
import {ButtonModule} from "primeng/button";
import {DialogModule} from "primeng/dialog";
import {FormsModule} from "@angular/forms";
import {InputTextModule} from "primeng/inputtext";
import {PaginatorModule} from "primeng/paginator";
import {RippleModule} from "primeng/ripple";
import {TableModule} from "primeng/table";
import {CalendarModule} from "primeng/calendar";


@NgModule({
  declarations: [
    DashboardComponent,
    WarrantiesComponent
  ],
  imports: [
    CommonModule,
    UserRoutingModule,
    SharedModule,
    ButtonModule,
    DialogModule,
    FormsModule,
    InputTextModule,
    PaginatorModule,
    RippleModule,
    SharedModule,
    TableModule,
    CalendarModule
  ], providers: [DatePipe]
})
export class UserModule {
}
