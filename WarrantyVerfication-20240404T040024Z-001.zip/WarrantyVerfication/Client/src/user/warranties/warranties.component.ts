import {Component, OnInit, ViewChild} from '@angular/core';
import {WarrantyType} from "../../types/warranty.type";
import {CompanyType} from "../../types/company.type";
import {ProductType} from "../../types/product.type";
import {UserService} from "../services/user.service";
import {ProgressCardComponent} from "../../shared/progress-card/progress-card.component";
import {DatePipe} from "@angular/common";
import html2canvas from "html2canvas";
import jsPDF from "jspdf";

@Component({
  selector: 'app-warranties',
  templateUrl: './warranties.component.html',
  styleUrl: './warranties.component.sass'
})
export class WarrantiesComponent implements OnInit {
  @ViewChild(ProgressCardComponent) prgCard!: ProgressCardComponent
  warranties: WarrantyType[] = [];
  addModalVisible: boolean = false;
  warranty: WarrantyType = {
    companyId: "", expiryDate: 0, id: "", productId: 0, startDate: 0, userId: ""
  };
  companies: CompanyType[] = [];
  selectedCompany: CompanyType = {
    id: "", name: ""
  };
  products: ProductType[] = [];
  selectedProduct: ProductType = {
    companyId: "", id: 0, name: "", warrantyInYears: 0
  };
  purchaseDate: string = '';

  constructor(private us: UserService, private datePipe: DatePipe) {
  }

  ngOnInit() {
    this.getAllCompanies()

  }

  showAddModal() {
    this.addModalVisible = true
  }

  addNewWarranty() {
    this.addModalVisible = false
    this.prgCard.setProgress('Requesting new Warranty', 0)
    let pDate = new Date(this.warranty.startDate)
    pDate.setFullYear(pDate.getFullYear() + parseInt(String(this.selectedProduct.warrantyInYears)))
    this.warranty.expiryDate = pDate.getTime()
    this.warranty.companyId = this.selectedCompany.id
    this.warranty.productId = this.selectedProduct.id
    if (this.warranty.startDate < 0) {
      this.prgCard.setProgress('start date is mandatory', 3)
      return
    }
    if (this.warranty.companyId.length < 1) {
      this.prgCard.setProgress('Select company from dropdown', 3)
      return;
    }
    if (this.warranty.expiryDate < 0) {
      this.prgCard.setProgress('expiry date is not calculated', 3)
      return;
    }
    if (this.warranty.productId === 0) {
      this.prgCard.setProgress('Select product from dropdown', 3)
      return;
    }
    this.us.addWarranty(this.warranty).then(r => {
      this.prgCard.setProgress('Warranty requested', 1)
      this.getAllWarranties()
    }).catch(er => {
      this.prgCard.setProgress('Warranty requesting failed', 3)
    })
  }

  getAllCompanies() {
    this.us.getAllCompanies().then(r => {
      this.companies = r
      this.getAllWarranties()
    })
  }

  getAllWarranties() {
    this.warranties = []
    this.us.getUserWarranties().then(r => {
      this.warranties = r
      console.log(this.warranties)
      this.warranties.map((w: WarrantyType) => {
        console.log(w.companyId, this.getCompanyNameById(w.companyId))
        w.companyName = this.getCompanyNameById(w.companyId)
      })
      console.log(this.warranties)
    })
  }

  getSelectedCompanyProducts() {
    this.us.getCompanyProducts(this.selectedCompany.id).then(r => {
      this.products = r
      console.log(r)
    })
  }

  onPurchaseDateChange() {
    this.warranty.startDate = Date.parse(this.purchaseDate)
  }

  protected readonly parseInt = parseInt;

  generatePDF(w: WarrantyType) {
    // const pdf = new jsPDF({
    //   orientation: "portrait", unit: "pt", format: "a4", hotfixes: ["px_scaling"], compress: true,
    // });

    const htmlString = `
    <div class="warranty-card">
        <h2>Warranty Card</h2>
        <p>Congratulations on your purchase!</p>
        <div class="warranty-details">
            <h3>Warranty Information:</h3>
            <p><strong>Product:</strong> ${w.product?.name}</p>
            <p><strong>Warranty Id:</strong> ${w.id}</p>
            <p><strong>Warranty Expiry:</strong> ${this.datePipe.transform(new Date(parseInt(String(w.expiryDate))), 'yyyy-MM-dd')}</p>
            <p><strong>Terms:</strong> This warranty covers defects in materials and workmanship. It does not cover
                damage caused by misuse or unauthorized repairs.</p>
            <p><strong>Contact:</strong> For warranty claims, please contact our nearest customer service center</p>
        </div>
    </div>`

    // const pdf = new jsPDF('p', 'px', 'a4');

    const element = document.createElement('div');
    // element.style.visibility = 'hidden';
    element.style.width = '800px'
    element.style.height = '400px'
    document.body.appendChild(element);

    element.innerHTML = htmlString;

    const options = {
      scale: 1,
      logging: true,
      useCORS: true
    };


    html2canvas(element, options).then((canvas) => {
      console.log('Canvas dimensions:', canvas.width, canvas.height);
      const imageData = canvas.toDataURL('image/png');

      console.log(element)

      if (canvas.width === 0 || canvas.height === 0) {
        console.error('Canvas is empty. Check HTML content and try again.');
        return;
      }

      console.log(canvas.width, canvas.height)


      const pdf = new jsPDF({
        orientation: 'landscape',
        unit: 'px',
        format: [800, 400]
      });


      pdf.addImage(imageData, 'PNG', 0, 0, canvas.width, canvas.height);
      pdf.save(w.id + '.pdf');

      document.body.removeChild(element);
    }).catch((error) => {
      console.error('Error rendering HTML to canvas:', error);
      document.body.removeChild(element);
    });
  }

  deleteWarranty(w: WarrantyType) {
    this.prgCard.setProgress('Deleting Warranty...', 0)
    this.us.deleteWarranty(w).then(r => {
      this.prgCard.setProgress('Warranty deleted', 1)
      this.getAllWarranties()
    }).catch(err => {
      this.prgCard.setProgress('Warranty deletion failed', 3)
    })
  }

  getCompanyNameById(cId: string) {
    console.log(this.companies)
    if (this.companies.length >= 1) {
      return this.companies.find(c => c.id === cId)?.name
    } else return ''
  }
}
