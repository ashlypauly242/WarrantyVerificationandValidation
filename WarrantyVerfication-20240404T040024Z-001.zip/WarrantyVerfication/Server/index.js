const Web3 = require('web3');
require('dotenv').config();
const schedule = require('node-schedule');
const web3 = new Web3("HTTP://127.0.0.1:7545");
const nodemailer = require('nodemailer');

const WAV_CONTRACT = require('./WarrantyVerification.json')
const WA_CONTRACT = require('./Warranty.json')

const ABI = WAV_CONTRACT.abi
const address = WAV_CONTRACT.networks[5777].address

let contract = new web3.eth.Contract(ABI, address)


let transporter = nodemailer.createTransport({
    service: 'gmail',
    auth: {
        user: process.env.EMAIL_ADDRESS,
        pass: process.env.EMAIL_APP_PASSWORD
    }
});

function getWarrantyContract(address) {
    return new web3.eth.Contract(WA_CONTRACT.abi, address)
}


function getAllWarranties() {
    return new Promise((resolve, reject) => {
        contract.methods['getAllWarranties']().call().then(w => {
            resolve(w)
        })
    })
}

function getUserMailId(uid) {
    return new Promise((resolve, reject) => {
        contract.methods['getUser'](uid).call().then(r => {
            resolve(r.email)
        })
    })
}

function getProductData(p) {
    return new Promise((resolve, reject) => {
        contract.methods['getProduct'](p).call().then(r => {
            resolve(r)
        })
    })
}

function sendEmailToUser(email, days, product) {
    getProductData(product).then(p => {
        console.log(`sending mail to ${email} for product ${p.name}`)
        let mailOptions = {
            from: process.env.EMAIL_ADDRESS,     // sender address
            to: email,  // list of receivers
            subject: `Reminder: Your Warranty for ${p.name} expires in ${days} days`,      // Subject line
            text: `Hi, \n This Email is to reminder that your warranty for the product ${p.name} expires in ${days}.please take necessary actions` // plain text body
        };

        try {
            transporter.sendMail(mailOptions, function (error, info) {
                if (error) {
                    console.log('failed sending email...');
                    // console.error('Error occurred:', error);
                } else {
                    console.log('Email sent:', info.response);
                }
            });
        } catch (error) {
            console.log(error);
        }


    })
}


function sendReminderMailsToUsers() {
    console.log("=====================================================================")
    getAllWarranties().then(w => {
        console.log(`${w.length} Warranties found`)
        let diff_days = 0
        w.forEach((w, i) => {
            getWarrantyContract(w).methods['getWarrantyData']().call().then((wd) => {
                if (parseInt(wd.status) === 1) {
                    diff_days = getDaysDifference(wd.startDate, wd.expiryDate)
                    if (diff_days === 30 || diff_days === 7 || diff_days === 1) {
                        getUserMailId(wd.userId).then(e => {
                            sendEmailToUser(e, diff_days, wd.productId)
                        })
                    }
                }
            })
        })
        console.log("=====================================================================")
    })
}

function getDaysDifference(timestamp1, timestamp2) {
    const millisecondsPerDay = 1000 * 60 * 60 * 24;
    const differenceInMilliseconds = Math.abs(timestamp1 - timestamp2);
    const daysDifference = Math.round(differenceInMilliseconds / millisecondsPerDay);
    return daysDifference;
}

sendReminderMailsToUsers()

schedule.scheduleJob('*/1 * * * *', function () {
    console.log('========================= Running Email Reminder Job ==========================')
    sendReminderMailsToUsers()
})
